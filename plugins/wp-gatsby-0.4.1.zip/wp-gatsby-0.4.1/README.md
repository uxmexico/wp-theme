# WP Gatsby

This plugin helps configure your WordPress site to be an optimized source for Gatsby site(s).
